import Swal from 'sweetalert2'

Swal.fire()

Swal.showLoading(Swal.getConfirmButton())
